<?php
	$final_redirect_link = "http://www.lnk123.com/SHken";
	header("Location: ".$final_redirect_link);
?>